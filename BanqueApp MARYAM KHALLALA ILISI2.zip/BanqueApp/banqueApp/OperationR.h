#pragma once

#include <iostream>
#include "Date.h"
#include "MAD.h"
#include "Operation.h"
using namespace std;
namespace Banque {
class OperationR : public Operation
	{

	public: 
		OperationR(Date* d, MAD* montant);
		
	private: 

	};
};
