#include "ComptePayant.h"
double Banque::ComptePayant::coutop = 0.05;

Banque::ComptePayant::ComptePayant(Client* c, MAD* m) : Compte(c,m)
{
}

bool Banque::ComptePayant::debiter(MAD* M)
{
	MAD* res = new MAD(*M * (1 + ComptePayant::coutop));
	return Compte::debiter(res);
}

void Banque::ComptePayant::crediter(MAD* M)
{
	MAD* res = new MAD(*M * (1 - ComptePayant::coutop));
	Compte::crediter(res);
}

void Banque::ComptePayant::consulter() const
{
	this->Compte::consulter();

}