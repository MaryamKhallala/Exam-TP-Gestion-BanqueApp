#include "OperationR.h"

Banque::OperationR::OperationR(Date* d, MAD* montant)
	: Operation(d,montant,"-")
{
}




