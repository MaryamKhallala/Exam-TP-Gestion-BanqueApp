#pragma once
namespace Banque {
	class MAD 
	{

	public:
		MAD(double val);
		MAD& operator+(const MAD& M) const;
		MAD& operator*(double d) const;
		MAD& operator*(MAD d) const;
		MAD& operator/(double d) const;
		MAD& operator-(const MAD& M) const;
		bool operator<=(const MAD& M)const;
		bool operator>=(const MAD& M) const;
		void afficher() const;
		void afficherEuro() const; //transferer le MAD en EURO
		void afficherDollar() const;  //transferer le MAD en DOLLAR



	private:
		double valeur;
	
	};
};
