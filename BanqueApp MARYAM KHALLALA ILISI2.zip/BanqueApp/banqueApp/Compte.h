#pragma once
#include <vector>
#include"Client.h"
#include "MAD.h"
#include "Operation.h"
#include "GC.h"
namespace Banque {
	class Compte
	{
			// Methodes
	public:
		Compte(Client*, MAD*); // avec parametres
		Compte(const Compte&);
		virtual void crediter(MAD* M);
		virtual bool debiter(MAD* M);
		bool verser(MAD* M, Compte& C);
		virtual void consulter() const = 0;
		 ~Compte();
	protected :bool checkSolde(MAD* M, MAD* dec);
			  MAD& pourcetage(MAD*); 
		//attributs
	private:
		vector <Operation*> historique;
		const int numcompte;
		static int count;
		Client* titulaire;
		MAD* solde;
		static MAD* plafond;
		GC* ref;
	};
};