#pragma once
#include "Compte.h"
namespace Banque
{
    class CompteCourant : public Compte
    {
    private:
        MAD* decouvert;
    public:
        CompteCourant(Client *c, MAD* m,MAD* decouvert);
        virtual void crediter(MAD* M);
        virtual bool debiter(MAD* M);
        void consulter() const override;
    };
};

