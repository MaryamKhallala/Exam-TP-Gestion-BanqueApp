#pragma once
class Date
{
private:
	int h, m, s, j, mo, a;
public:
	Date();
	void afficher();

};

