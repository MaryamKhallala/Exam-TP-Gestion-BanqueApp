#include "CompteCourant.h"

Banque::CompteCourant::CompteCourant(Client* c, MAD* m,MAD* dec)
	: Compte(c,m)
{
	this->decouvert = dec;
}

void Banque::CompteCourant::crediter(MAD* M)
{
	this->Compte::crediter(M);
}

bool Banque::CompteCourant::debiter(MAD* M)
{
	if (this->checkSolde(M, this->decouvert))
		return this->Compte::debiter(M);
	return false;
}

void Banque::CompteCourant::consulter() const
{
	this->Compte::consulter();
}