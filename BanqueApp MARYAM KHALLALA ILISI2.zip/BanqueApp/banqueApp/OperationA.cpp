#include "OperationA.h"

Banque::OperationA::OperationA(Date* d, MAD* montant)
:Operation(d, montant, "+")
{
}
