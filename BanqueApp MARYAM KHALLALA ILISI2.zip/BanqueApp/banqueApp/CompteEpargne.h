#pragma once
#include "Compte.h"
#include "MAD.h"
namespace Banque {
	class CompteEpargne : public Compte
	{
	private:
		double tauxI;
	public:
		CompteEpargne(Client* c, MAD* m, double TI);
		void calculInteret();
		void consulter() const override;
	};
};

