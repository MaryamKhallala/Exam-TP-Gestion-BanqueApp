#pragma once
class GC
{
private : 
	int compt; 
public: 
	GC(int); 
	void incre();
	int decr();
};

