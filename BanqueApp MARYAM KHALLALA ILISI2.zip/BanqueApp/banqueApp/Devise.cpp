#include "Devise.h"
#include  <iostream>
using namespace std;
using namespace Banque;
Devise::Devise(double val)
{
	this->valeur = val;
}

Devise& Devise::operator+(const Devise& M) const
{
	Devise* res = new Devise (this->valeur + M.valeur); 
	return *res;
}

Devise& Devise::operator-(const Devise& M) const
{
	Devise* res = new Devise(this->valeur - M.valeur);
	return *res;
}

Devise& Banque::Devise::operator*(const Devise& M) const
{
	Devise* res = new Devise(M.valeur * this->valeur);
	return *res;
	// TODO: ins�rer une instruction return ici
}

bool Devise::operator<=(const Devise& M) const
{
	return this->valeur <= M.valeur;
}

bool Devise::operator>=(const Devise& M) const
{
	return this->valeur >= M.valeur;
}

void Devise::afficher() const
{
	cout << "le solde est : " << this->valeur << "MAD" << endl;
}

void Banque::Devise::afficherEuro() const
{
	cout << "le solde est : " << this->valeur/10 << "MAD" << endl;
}

void Banque::Devise::afficherDollar() const
{
	cout << "le solde est : " << this->valeur/9 << "MAD" << endl;
}

