#include "Compte.h"
#include"Operation.h"
#include"OperationA.h"
#include"OperationR.h"
#include<iostream>
using namespace std;
using namespace Banque;
MAD* Compte::plafond = new MAD(2000);
int Compte::count = 0;
Banque::Compte::Compte(Client* titu, MAD* sol):numcompte(++count)
{
	this->ref = new GC(1);
	this->titulaire = titu;
	this->solde = sol;
	this->historique = vector<Operation*>();
}

void Banque::Compte::crediter(MAD*M)
{
	*(this->solde) = *(this->solde)+*M;
	Date* d = new Date();
	Operation* op = new OperationA(d, M);
	this->historique.push_back(op);
}

bool Banque::Compte::debiter(MAD*M)
{
	if (*(this->solde) >= *M && *M <= *(Compte::plafond))
	{
		*(this->solde) = *(this->solde) - *M;
		Date* d = new Date();
		Operation* op = new OperationR(d, M);
		this->historique.push_back(op);
		return true;
	}
	return false;
}

Banque::Compte::Compte(const Compte& c):numcompte(c.numcompte)
{
	this->ref = c.ref;
	this->ref->incre();
	this->titulaire = c.titulaire;
	this->historique = c.historique;

}

bool Banque::Compte::verser(MAD* M, Compte& C)
{
	if (this->debiter(M)==true) {
		C.crediter(M);
		return true;
	}
	return false;
}


void Banque::Compte::consulter() const
{
	cout << "num compte=" << this->numcompte << endl;
	this->solde->afficher();
	cout << "Historique des operations " << endl;
	//this->titulaire->Afficher();

	for (int i = 0; i <this->historique.size(); i++)
	{
		this->historique[i]->afficher();
	}
}

Compte::~Compte() {

	if (this->titulaire!=nullptr && this->ref->decr() ==0 ) 
	{
		delete this->titulaire; 
		this->titulaire = nullptr;
	}
}

bool Banque::Compte::checkSolde(MAD* M, MAD*dec)
{
	if (*(this->solde) - *(M) >= *dec)
		return true;
	return false;
}

MAD& Banque::Compte::pourcetage(MAD* a)
{
	return (*a) * (*this->solde);
}
