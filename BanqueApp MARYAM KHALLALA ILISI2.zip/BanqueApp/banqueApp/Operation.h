#pragma once
#include <iostream>
#include "Date.h"
#include "MAD.h"
using namespace std;
namespace Banque
{
	class Operation
	{
	private:
		static int compteur;
		const int num;
		Date* d;
		MAD* montant;
		string libelle;
	public: 
		Operation(Date* d, MAD* montant,string);
		virtual void afficher();
	};
};

