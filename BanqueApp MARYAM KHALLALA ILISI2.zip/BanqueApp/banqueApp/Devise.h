#pragma once
namespace Banque {
	class Devise
	{
	private:
		double valeur;
	public:
		Devise(double val);
		Devise& operator+(const Devise& M) const;
		Devise& operator-(const Devise& M) const;
		Devise& operator*(const Devise& M) const;


		bool operator<=(const Devise& M)const;
		bool operator>=(const Devise& M) const;
		void afficher() const;
		void afficherEuro() const;   //transferer le MAD en EURO
		void afficherDollar() const; //transferer le MAD en DOLLAR
	};
};

