#pragma once
#include <iostream>
#include "Operation.h"
#include "Date.h"
#include "MAD.h"
#include "Operation.h"
using namespace std;
namespace Banque {
	class OperationA : public Operation
	{

	public:
		OperationA(Date* d, MAD* montant);

	private:
	};
};
