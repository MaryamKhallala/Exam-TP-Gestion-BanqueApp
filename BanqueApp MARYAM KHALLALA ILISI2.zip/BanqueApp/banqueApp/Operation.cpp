#include <iostream>
#include "Operation.h"
using namespace Banque;
int Operation::compteur = 1;
Banque::Operation::Operation(Date* d, MAD* montant, string s) : num(compteur++)
{
	this->d = d;
	this->montant = montant;
	this->libelle = s;

}

void Banque::Operation::afficher()
{
	this->d->afficher();
	cout << " | num : " << this->num << " || " << this->libelle;
	this->montant->afficher();
	this->montant->afficherEuro();
	this->montant->afficherDollar();

}
